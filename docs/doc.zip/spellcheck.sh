#!/usr/bin/sh
hunspell -d en_US -l documentation.tex
